"""Record bounded source passages and validate saved capture anchors."""
import csv
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'literature/resume_r04_2026_10_16'

def main():
    rows=[
        ('R04C01','L06','https://link.springer.com/article/10.1007/s40747-023-01013-7','Proposed model; lines94-98','reading_capture_3.json','cross-validation predictions','Stacking meta inputs use CV predictions; random80/20','No full nesting/validity certification; no matched score comparison'),
        ('R04C02','L09','https://iris.unicas.it/retrieve/a40146bd-61d7-4a77-98c7-cf72f480c839/2024%20-%20Machine%20Learning%20in%20Network%20Intrusion%20Detection%20-%20A%20Cross-Dataset%20Generalization%20Study.pdf','Indexed Introduction; printed144490','reading_capture_1.json','within-dataset scenario','Within-dataset vs cross-dataset scenarios differ','No full-paper read or numeric findings imported'),
        ('R04C03','L03','https://intrusion-detection.distrinet-research.be/CNS2022/Tools_Documentation.html','Tools & Documentation; Paper Code repository','reading_capture_2.json','labelling code','Authors publish labeling/experiment code for dataset audit','No transfer of CIC-specific errors to UNSW; page conflict still open'),
        ('R04C04','D01','https://lhu.edu.vn/783/41967/Lich-bao-ve-luan-an-tien-si-cap-Truong-nganh-Khoa-hoc-may-tinh-NCS-Hoang-Ngoc-Thanh-thang-12-nam-2022.html','Official announcement; title/date lines25-36','reading_capture_4.json','31/12/2022','Domestic ensemble/preprocessing topic is documented','No thesis results or successful defense inferred from schedule'),
        ('R04C05','D02','https://uet-test.uet.edu.vn/wp-content/uploads/2025/11/Tom-tat-LATS-cua-NCS-Vo-Van-Hoang_QH-20-HTTT-tieng-Viet-1.pdf','Cover/PDF1; Objectives printed1/PDF3','reading_capture_4.json','soft','Domestic summary includes voting/stacking objectives and data quality/sampling','Not whole thesis; no direct metric comparison or NCKH deployment claim'),
    ]
    fields=['claim_id','source_id','source_url','locator','capture','keyphrase','allowed_claim','forbidden_inference']
    path=OUT/'source_claim_map.csv'
    if path.exists():
        raise FileExistsError(path)
    with path.open('x',encoding='utf-8',newline='') as f:
        writer=csv.writer(f);writer.writerow(fields);writer.writerows(rows)
    checks={}
    for row in rows:
        p=OUT/row[4]
        value=json.loads(p.read_text(encoding='utf-8'))
        text=value if isinstance(value,str) else json.dumps(value,ensure_ascii=False)
        checks[row[0]+'_capture_exists']=p.is_file()
        checks[row[0]+'_keyphrase_present']=row[5].lower() in text.lower()
    (OUT/'reading_validation.json').write_text(json.dumps(dict(checks=checks,passed=all(checks.values()),scope='Saved source passage anchors only; substantive interpretation bounded in notes'),indent=2),encoding='utf-8')
    print(json.dumps(dict(passed=sum(checks.values()),total=len(checks))))
    if not all(checks.values()):raise SystemExit(1)

if __name__=='__main__':main()
