# PROJECT AUDIT — 16/10/2026 (Asia/Saigon)

## Phạm vi và cách đọc

Hồ sơ phục vụ audit độc lập, không phải bản nộp cuối. Phiên đóng gói chỉ đọc file, hash và tạo ZIP bằng thư viện chuẩn Python; không training, tuning, inference, bootstrap hay đánh giá official TEST. Không sửa bộ nhớ hoặc file có trước phiên này. Mọi số kiểm định nghiên cứu dưới đây là evidence lịch sử được kế thừa, không phải kiểm định khoa học vừa chạy lại.

Đọc MASTER_PROMPT.md, .research_memory/RESEARCH_CANON.md, docs/ROADMAP_CURRENT.md, docs/ROADMAP_RECONCILIATION.md, docs/RESUME_AUDIT_R04_2026-10-16.md và release/RELEASE_BLOCKERS.md. Các cập nhật r04 mới hơn bảng r01/r02/r03. Nhãn thư mục phase cũ không đồng nghĩa mã Phase chuẩn. Giữ nguyên các bản cũ để kiểm tra provenance và sai lệch roadmap.

DONE dưới đây chỉ xác nhận phần việc có output và kiểm định lịch sử trong scope ghi rõ. PARTIAL nghĩa đã có evidence nhưng còn thiếu gate; TODO nghĩa chưa có sản phẩm cuối đủ gate. Không coi sự tồn tại của script hay lời ghi DONE là bằng chứng thực nghiệm. MANIFEST.csv cho biết chính xác file nào được chia sẻ; STATE_MANIFEST_CHECK.json kiểm tra lại manifest STATE hiện hành bằng SHA-256.

## Roadmap chuẩn Phase 0–20

| Phase | Trạng thái | Evidence thực tế / giới hạn và phần còn thiếu |
|---|---|---|
| P00 Research design | PARTIAL | notebook/phase01/phase1_frozen_research_design_v1.md; .research_memory/RESEARCH_CANON.md; proposal/researchwrite/nckh-ids/. Có RQ/foundation, chưa xác minh bộ giả thuyết tiên nghiệm riêng; chưa đề cương DOCX/PDF đạt gate. |
| P01 Literature/gap | PARTIAL | literature/literature_matrix.csv; literature/gap_matrix.md; literature/resume_r04_2026_10_16/. Legacy metadata 11/12 verified theo ledger, không phải full-text/systematic-review completion. |
| P02 Dataset | DONE (scope UNSW binary) | results/data_audit/unsw_nb15/; results/reproducibility/p15_03_dataset/; docs/research/P15_03_DATASET_PROVENANCE.md. Nguồn/schema/checksum/split có kiểm tra lịch sử; CIC chỉ candidate, chưa external validation. Raw không nằm trong ZIP. |
| P03 Data/leakage audit | DONE (audit có giới hạn) | results/data_audit/unsw_nb15_overlap/ và unsw_nb15_views/; p15_03_dataset, p15_04_protocol. Có overlap/conflict findings; DONE audit không chứng nhận split độc lập hoặc pipeline hoàn toàn leakage-free. |
| P04 EDA | DONE (EDA nghiên cứu) | results/eda/unsw_nb15/tables/; src/ và notebook/ tương ứng. Bảng/source giữ lại, ảnh bị loại theo yêu cầu; publication QA thuộc P16. |
| P05 Feature selection | PARTIAL | results/feature_selection/unsw_nb15/stage1/ và stage2/. Có subset/stability/RFECV; FS fit trên full TRAIN trước development CV, không fold-local đầy đủ theo MASTER. Không chạy lại để hợp thức hóa. |
| P06 Baselines | DONE (benchmark đã lưu, có giới hạn) | results/baselines/unsw_nb15/development_cv/: fold/aggregate metrics, runtime, metadata; src/models/. Development optimism do FS phải giữ trong kết luận. |
| P07 Ensembles/diversity | DONE (thử nghiệm đã lưu) | results/ensemble/unsw_nb15/phase7_1_diversity/ và phase7_2_ensemble_cv/: diversity, OOF summary, folds, aggregates. OOF row-level lớn bị loại, metadata/hash tham chiếu giữ lại. |
| P08 Framework | PARTIAL | docs/research/ENSEMBLE_FRAMEWORK.md; freeze_candidates.json; source. Documentation closure đã có; không chứng minh thuật toán mới/novelty. |
| P09 Imbalance | PARTIAL | notebook/phase13/ và ablation/comparability evidence. Có class-weight/no-resampling scope, thiếu matched resampling contrasts; không kết luận sampling vô ích. |
| P10 Tuning | DONE (executed scope có giới hạn) | results/tuning/unsw_nb15/phase8_controlled/: grid results, frozen candidates, metadata. Meta tuning không fully nested; official TEST đã mở nên không retune/reselect/đổi threshold. |
| P11 Evaluation protocol | DONE (binary saved-results closure) | results/final_evaluation/unsw_nb15/phase9_holdout/ và phase11_evaluation_closure/; results/reproducibility/resume_2026_10_16/clean_replay_report.json. Confusion/per-class/weighted metrics được bổ sung, 3 CSV replay byte-identical theo log lịch sử. Không phải multiclass hay fresh ML evaluation. |
| P12 Statistics/stability | PARTIAL | results/final_analysis/unsw_nb15/phase10_statistics/: paired bootstrap CI, McNemar-Holm, Wilson. Phần thống kê đã thực hiện có evidence; chưa repeated-training stability đầy đủ, CI có điều kiện trên benchmark rows. |
| P13 Ablation | PARTIAL | results/ablation/unsw_nb15/phase13_ablation/: matrix, comparability audit, 19 input hashes; notebook/phase13/phase13_ablation_summary.md. Retrospective synthesis, thiếu component leave-one-out/full factorial; RF42/RF17 khác cả hyperparameters. |
| P14 Error analysis | DONE (descriptive scope) | results/final_analysis/unsw_nb15/phase14_error_analysis_step1, step3, step4, step5; docs/research/PHASE14_ERROR_ANALYSIS_CLOSURE.md. Per-attack/errors/feature-pattern summaries và reconciliation có; không phải multiclass hay causal attribution. |
| P15 Reproducibility | PARTIAL | results/reproducibility/; docs/research/R04_ML_SMOKE_REPORT.md. Hash/protocol/aggregate replay có; smoke TRAIN-only 2000/500 rows, initial 41/42 fail và repaired 45/45 có evidence riêng. Original training environment UNKNOWN, chưa full-TRAIN reconstruction/final models. Model SMOKE_ONLY không phải final inference demo. |
| P16 Figures/tables | PARTIAL | results/figures/p16_paired_effects_2026_10_16/: source_data/metadata/caption/QA có; một figure đã QA lịch sử. Hình cũ là draft, chưa QA toàn bộ. ZIP chỉ giữ source/data/QA, không ảnh. |
| P17 Report/proposal | PARTIAL | templates/original/latex/; proposal/researchwrite/nckh-ids/drafts/De_cuong_noi_dung_review_r04.md; notebook/phase12/phase13 historical reporting drafts. Có nội dung MD, full argument review bị quota, chưa filled/rendered proposal DOCX/PDF và chưa báo cáo IDS LaTeX/PDF đạt gate. Template Android là mẫu, không phải kết quả IDS. |
| P18 References | PARTIAL | literature/resume_r04_2026_10_16/; literature/verification_2026_10_16/. L03 page conflict 254–262 vs 254–263; U01/U03 warnings còn mở; chưa final verified bibliography. |
| P19 Availability/release | PARTIAL | docs/research/DATA_CODE_AVAILABILITY.md; docs/research/REPRODUCIBILITY_MAP.md; manifests/environment/config. License/repository/version và release gates chưa đủ. Bộ audit này không đóng gate release. |
| P20 Peer review/defense QA | TODO (gate cuối) | defense/ có Q&A20, script12 vị trí/720 giây, runbook/checklist và validation dạng draft. Thiếu final manuscript, review3 góc hoàn chỉnh, slides PPTX/PDF, render/rehearsal/final inference demo và release acceptance. |

## Kết luận nghiên cứu cần kiểm tra độc lập

Nghiên cứu hiện là binary Normal=0/Attack=1 trên UNSW-NB15 official TRAIN 175341 / TEST 82332; 42 predictors và stable17. Attack-family miss analysis không phải mô hình multiclass. Freeze RF42/Stack42/RF17, threshold0.5 phải giữ nguyên. Pipeline chưa được chứng minh hoàn toàn leakage-free: FS ngoài development folds; meta tuning không fully nested; overlap và phụ thuộc giữa flows giới hạn diễn giải.

Saved evidence cho Stack42−RF42: ΔMacro-F1 khoảng +0.00049669, paired95%CI [−0.00031180,+0.00130895], Holm McNemar p≈0.4683765; giảm142FP nhưng tăng118FN. Không chứng minh superiority tổng thể hoặc statistical equivalence. RF17 thể hiện bundled performance/cost trade-off, không isolated causal feature ablation. Kiểm tra trực tiếp CSV phase9/phase10 và CLAIM_EVIDENCE_MATRIX; không lấy bản prose cũ làm nguồn số liệu cuối.

P15 vẫn PARTIAL, P16/P18/P19 đang tiến triển; G0–G6 chưa đóng, NOT_READY_FOR_SUBMISSION. RQ4 trả lời một phần, RQ5 thiếu matched resampling; không external validation/live IDS deployment. Các mâu thuẫn lịch sử đáng xem: DOCX từng ghi9 bảng được sửa thành8; stale memory hashes đã giải thích tại r03; nhãn reporting phase11–13 cũ đã được mapping về P16–19 nhưng file không move. Không đủ cơ sở từ đóng gói để kết luận Codex chưa từng làm sai pipeline; hồ sơ giữ source, failures, decisions và provenance để người review kiểm tra.

## Tài liệu thiếu / hướng dẫn audit

Original `Văn bản đã dán (1)(4).txt`: AUTHOR_INPUT_NEEDED theo memory; không suy diễn nội dung. Mẫu ZIP/DOCX thật đã có; bản DOCX và nguồn LaTeX được giữ, ZIP cũ/ảnh mẫu bị loại. Thông tin tác giả/GVHD/chữ ký/tính áp dụng lịch/ngân sách còn cần xác nhận.

Upload cả hai ZIP và các sidecar PROJECT_STATUS.md, MANIFEST.csv, VALIDATION.json nếu giao diện cho phép. PROJECT_TREE.txt quét đầy đủ cả file loại trừ và file audit mới; EXCLUDED_FILES.csv liệt kê từng file ngoài payload, kích thước và lý do. Bảng CSV aggregate/JSON/log/Markdown được giữ cả thư mục cũ; không lọc theo tuổi file. PDF/paper binaries/ảnh, raw/interim data, venv, .git, cache, models, ZIP cũ và prediction/OOF lớn không nằm trong payload. Do đó ChatGPT có thể audit source/evidence chain, nhưng không thể tự xác minh lại prediction-level statistics nếu thiếu các file bị loại; không trình bày giới hạn đó thành scientific PASS.
