"""Read-only source audit packager. Python standard library only; no project imports."""
from pathlib import Path
import collections
import csv
import hashlib
import io
import json
import os
import re
import sys
import zipfile
import zlib
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parent.parent
OUT = Path(__file__).resolve().parent
LIMIT = 20_000_000  # conservative decimal MB, including ZIP overhead
TEXT = {'.py','.md','.txt','.json','.csv','.tsv','.yaml','.yml','.toml','.ini',
        '.cfg','.conf','.lock','.log','.tex','.bib','.sty','.cls','.sh','.ps1',
        '.bat','.cmd','.ipynb','.r','.html','.xml','.rst','.gitignore','.gitattributes'}
IMAGES = {'.png','.jpg','.jpeg','.gif','.webp','.svg','.bmp','.tif','.tiff','.ico'}
BINARY = {'.pkl','.pickle','.joblib','.onnx','.h5','.hdf5','.pt','.pth','.bin',
          '.exe','.dll','.pyd','.so','.pyc','.pyo','.whl','.npy','.npz','.parquet','.feather'}
CACHE = {'.git','__pycache__','.pytest_cache','.mypy_cache','.ruff_cache',
         '.cache','cache','caches','node_modules','.venv','venv','env','site-packages'}
SECRET_NAME = re.compile(r'(^\.env($|\.)(?!example|sample|template)|credential|secrets?\.|id_rsa|id_ed25519|\.pem$|\.key$|\.pfx$|\.p12$)', re.I)
SECRET_BODY = [re.compile(rb'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----'),
               re.compile(rb'\bAKIA[0-9A-Z]{16}\b'),
               re.compile(rb'\bgh[pousr]_[A-Za-z0-9]{30,}\b'),
               re.compile(rb'\bsk-(?:proj-|svcacct-)?[A-Za-z0-9_-]{24,}\b'),
               re.compile(rb'\bxox[baprs]-[A-Za-z0-9-]{20,}\b'),
               re.compile(rb'(?i)["\']?(?:api[_-]?key|access[_-]?token|client[_-]?secret|password)["\']?\s*[:=]\s*["\']([A-Za-z0-9/+_=.-]{12,})["\']')]

def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for b in iter(lambda: f.read(1024*1024), b''): h.update(b)
    return h.hexdigest()

def walk():
    rows=[]
    for base, dirs, files in os.walk(ROOT, followlinks=False):
        dirs.sort(); files.sort()
        for name in files:
            p=Path(base)/name
            if p.is_symlink():
                raise RuntimeError('Symlink requires explicit handling: '+str(p))
            st=p.stat()
            rows.append({'path':p.relative_to(ROOT).as_posix(),'size_bytes':st.st_size,
                         'mtime_ns':st.st_mtime_ns})
    return rows

def save_csv(name, fields, rows):
    with (OUT/name).open('x',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(rows)

def save_json(name,obj):
    with (OUT/name).open('x',encoding='utf-8') as f:
        json.dump(obj,f,ensure_ascii=False,indent=2)

def classify(row, runtimes):
    rel=row['path']; p=Path(rel); parts=p.parts; low=[x.lower() for x in parts]
    ext=p.suffix.lower()
    if p.parts[0]==OUT.name:
        if p.name in {'PROJECT_STATUS.md','HANDOFF.md','build_audit.py'}:return 'CODE_DOCS',''
        return '', 'Audit sidecar/generated archive; distributed separately; no recursive packaging'
    if any(x in CACHE for x in low):return '', 'Version control / environment / cache'
    if any(rel==r or rel.startswith(r+'/') for r in runtimes):return '', 'Virtual environment detected via pyvenv.cfg'
    if len(low)>1 and low[0]=='data' and low[1] in {'raw','processed','interim'}:return '', 'Dataset rows (raw/processed/interim); excluded for lightweight audit'
    if SECRET_NAME.search(p.name):return '', 'Potential credential/private-key filename; omitted without exposing value'
    if ext in IMAGES:return '', 'Image/vector artwork excluded by request; source tables/code retained'
    if ext in BINARY:return '', 'Model/compiled/binary artifact excluded'
    if ext in {'.zip','.7z','.rar','.tar','.gz','.bz2','.xz'}:return '', 'Existing compressed archive excluded; no recursive ZIP'
    if ext=='.pdf':return '', 'Binary PDF/paper/render output; source/metadata retained where available'
    if ext in {'.csv','.tsv'} and row['size_bytes']>2_000_000 and any(x in rel.lower() for x in ['predict','/oof/','probabilit']):return '', 'Large row-level prediction/OOF CSV (>2,000,000 bytes); aggregate evidence retained'
    if ext not in TEXT and ext!='.docx' and p.name.lower() not in {'license','makefile','dockerfile','.gitignore','.gitattributes'}:return '', 'Unclassified/binary format; explicitly excluded for review'
    content=(ROOT/rel).read_bytes()
    if ext=='.docx':
        with zipfile.ZipFile(io.BytesIO(content)) as z:
            content=b'\n'.join(z.read(n) for n in z.namelist() if n.endswith('.xml'))
    if any(pat.search(content) for pat in SECRET_BODY):return '', 'Potential embedded credential detected by conservative content scan; review locally'
    group='RESULTS' if (low[0]=='results' or ext in {'.csv','.tsv'} or (ext in {'.json','.log'} and any(x in rel.lower() for x in ['validation','qa_log','reproducib','checkpoint']))) else 'CODE_DOCS'
    return group,''

def main():
    sys.stdout.reconfigure(encoding='utf-8')
    before=walk()
    originals=[r for r in before if not r['path'].startswith(OUT.name+'/')]
    for r in originals:r['sha256']=sha(ROOT/r['path'])
    save_csv('PRESERVATION_BASELINE.csv',['path','size_bytes','mtime_ns','sha256'], originals)
    runtimes={str(Path(r['path']).parent).replace('\\','/') for r in before if Path(r['path']).name=='pyvenv.cfg'}
    checks=[]
    state=json.loads((ROOT/'.research_memory/STATE.json').read_text(encoding='utf-8-sig'))
    for row in state.get('artifact_manifest',[]):
        p=ROOT/row['path']; actual=sha(p) if p.is_file() else None
        checks.append({'path':row['path'],'expected':row.get('sha256'),'actual':actual,'match':actual==row.get('sha256')})
    save_json('STATE_MANIFEST_CHECK.json',{'scope':'Read-only current STATE artifact SHA-256 check; not scientific re-evaluation','checks':checks,'matches':sum(r['match'] for r in checks),'total':len(checks)})
    selected=collections.defaultdict(list);excluded=[]
    for r in before:
        group,reason=classify(r,runtimes)
        if group:selected[group].append(r)
        else:excluded.append(dict(path=r['path'],size_bytes=r['size_bytes'],reason=reason))
    manifest=[];archives=[]
    for group in ['CODE_DOCS','RESULTS']:
        # Bound compressed size before writing; no scratch archive or deletion.
        batches=[];batch=[];estimated=22
        for row in sorted(selected[group],key=lambda r:r['path']):
            data=(ROOT/row['path']).read_bytes()
            c=zlib.compressobj(9,zlib.DEFLATED,-15)
            compressed=c.compress(data)+c.flush()
            cost=len(compressed)+2*len(row['path'].encode('utf-8'))+150
            if cost+22>LIMIT:raise RuntimeError('Single file exceeds ZIP limit, not silently dropped: '+row['path'])
            if batch and estimated+cost>LIMIT:batches.append(batch);batch=[];estimated=22
            batch.append(row);estimated+=cost
        if batch:batches.append(batch)
        for i,rows in enumerate(batches,1):
            name='NCKH_'+group+(f'_part{i:02d}' if len(batches)>1 else '')+'.zip'
            with zipfile.ZipFile(OUT/name,'x',zipfile.ZIP_DEFLATED,compresslevel=9,allowZip64=True) as z:
                for row in rows:
                    z.write(ROOT/row['path'],row['path'])
                    manifest.append({'archive':name,'path':row['path'],'size_bytes':row['size_bytes'],'sha256':sha(ROOT/row['path'])})
            size=(OUT/name).stat().st_size
            assert size<=LIMIT,(name,size)
            archives.append({'archive':name,'size_bytes':size,'files':len(rows),'sha256':sha(OUT/name)})
    save_csv('MANIFEST.csv',['archive','path','size_bytes','sha256'],manifest)
    # Verify every archived byte and CRC against source, not just directory entries.
    verified=0
    for a in archives:
        expected={r['path']:r for r in manifest if r['archive']==a['archive']}
        with zipfile.ZipFile(OUT/a['archive']) as z:
            assert z.testzip() is None
            assert len(z.namelist())==len(set(z.namelist()))==len(expected)
            for n in z.namelist():
                b=z.read(n);r=expected[n]
                assert len(b)==r['size_bytes'] and hashlib.sha256(b).hexdigest()==r['sha256']==sha(ROOT/n)
                verified+=1
    after={r['path']:r for r in walk()}
    preserved=0
    for r in originals:
        a=after.get(r['path'])
        assert a and a['size_bytes']==r['size_bytes'] and a['mtime_ns']==r['mtime_ns'] and sha(ROOT/r['path'])==r['sha256'],r['path']
        preserved+=1
    save_json('VALIDATION.json',{'created_utc':datetime.now(timezone.utc).isoformat(),
        'package_status':'PASS','zip_limit_bytes':LIMIT,'archives':archives,
        'payload_files_verified_crc_sha256':verified,'preexisting_files_verified_unchanged':preserved,
        'state_manifest_matches':sum(r['match'] for r in checks),'state_manifest_total':len(checks),
        'research_gate_status':'NOT_READY_FOR_SUBMISSION; no scientific phase advanced',
        'execution':'stdlib filesystem read/hash/ZIP only; no project module imported or experiment executed',
        'secret_scan':'Conservative filename + private-key/common-token/literal credential patterns; suspected files omitted; not an absolute guarantee',
        'sidecar_policy':'MANIFEST covers ZIP payload. SIDECAR_SHA256 covers final sidecars/archives except itself. PROJECT_TREE and inventory include all final new files; no recursive archive inclusion.'})
    # These three sidecars describe the final file universe. Their self sizes/hashes
    # are deliberately not embedded in their own records (avoids recursive hashes).
    future=['EXCLUDED_FILES.csv','PROJECT_TREE.txt','FULL_INVENTORY.csv','SIDECAR_SHA256.csv']
    current=walk(); seen={r['path'] for r in current}
    for name in future:
        rel=OUT.name+'/'+name
        if rel not in seen:current.append({'path':rel,'size_bytes':None,'mtime_ns':None})
    payload={r['path']:r['archive'] for r in manifest}
    old_ex={r['path']:r for r in excluded}
    all_ex=[];inv=[]
    for r in sorted(current,key=lambda r:r['path']):
        rel=r['path'];group=payload.get(rel,'')
        reason='' if group else old_ex.get(rel,{}).get('reason','Audit sidecar/generated archive distributed separately; metadata finalized after ZIPs')
        if not group:all_ex.append({'path':rel,'size_bytes':r['size_bytes'] if r['size_bytes'] is not None else 'SELF_REFERENTIAL_SEE_FILESYSTEM','reason':reason})
        inv.append({'path':rel,'size_bytes':r['size_bytes'] if r['size_bytes'] is not None else 'SELF_REFERENTIAL_SEE_FILESYSTEM','delivery':group or 'EXCLUDED_FROM_ZIP','reason':reason})
    save_csv('EXCLUDED_FILES.csv',['path','size_bytes','reason'],all_ex)
    save_csv('FULL_INVENTORY.csv',['path','size_bytes','delivery','reason'],inv)
    descriptions={'.research_memory':'State, decisions, evidence, historical checkpoints','src':'Research pipelines and analysis code','tools':'Audit/replay/utilities','tests':'Existing validation tests','results':'Experimental evidence, statistics, ablation, reproducibility','notebook':'Research design and historical phase notes','docs':'Current roadmap, reconciliation, methodology','data':'Datasets excluded from ZIPs','templates':'Original/working administrative and LaTeX templates','proposal':'Proposal drafts, form mapping, reviews','defense':'Defense drafts and validations','literature':'Reference ledgers, source captures, gap matrix','exports':'Historical handoff/export evidence','NCKH_SHARE_FOR_REVIEW':'New audit package and verification sidecars','.git':'Version-control objects excluded'}
    dirs=set()
    for r in current:
        p=Path(r['path']).parent
        while p!=Path('.'):
            dirs.add(p.as_posix());p=p.parent
    with (OUT/'PROJECT_TREE.txt').open('x',encoding='utf-8') as f:
        f.write('NCKH / full project file tree, including new audit outputs\nAll file paths enumerated; directory links not followed. No hidden-folder pruning.\nLegend: ZIP name = included; EXCLUDED = consult EXCLUDED_FILES.csv.\n\n')
        entries=sorted([(d,True) for d in dirs]+[(r['path'],False) for r in current],key=lambda x:tuple(x[0].split('/')))
        for rel,is_dir in entries:
            p=Path(rel);depth=len(p.parts)-1
            suffix=' / '+descriptions.get(rel,'') if is_dir else ' ['+payload.get(rel,'EXCLUDED')+']'
            f.write('  '*depth+p.name+('/' if is_dir else '')+suffix+'\n')
    save_csv('SIDECAR_SHA256.csv',['path','size_bytes','sha256'],[
        {'path':p.relative_to(ROOT).as_posix(),'size_bytes':p.stat().st_size,'sha256':sha(p)}
        for p in sorted(OUT.iterdir()) if p.is_file() and p.name!='SIDECAR_SHA256.csv'])
    final=walk(); finalpaths={r['path'] for r in final}
    assert finalpaths=={r['path'] for r in current},'Final inventory incomplete'
    assert set(payload).isdisjoint({r['path'] for r in all_ex})
    assert set(payload)|{r['path'] for r in all_ex}==finalpaths
    print(json.dumps({'archives':archives,'verified_payloads':verified,'unchanged_originals':preserved,
        'state_matches':sum(r['match'] for r in checks),'state_total':len(checks),
        'final_files_including_audit':len(final),'excluded_from_zip':len(all_ex),
        'credential_candidates':[r['path'] for r in all_ex if 'credential' in r['reason'].lower()]},ensure_ascii=False,indent=2))

if __name__=='__main__':main()
